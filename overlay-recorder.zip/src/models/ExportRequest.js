const ExportRequest = {
  type: "object",
  required: [],
  properties: {
    id: { type: "string" }
  }
};

export default ExportRequest;
